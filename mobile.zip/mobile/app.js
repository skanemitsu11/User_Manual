'use strict';
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

// ---- マスタ ---------------------------------------------------------------

// 展開図の背景とパネル多角形（tools/build_diagram.py が vehicle-segmentation.png から生成）
const DIAGRAM = window.DIAGRAM;
const PARTS = DIAGRAM.parts;
const partLabel = id => (PARTS.find(p => p.id === id) || {}).label || id;

// 基本事項の記入欄
const FIELDS = [
  {key:'lotNo', label:'出品番号', type:'num'},
  {key:'score', label:'評価点', type:'choice', cls:'score', options:['S','6','5','4.5','4','3.5','3','2','1','R','RA','0']},
  {key:'name', label:'車名', type:'text', options:['ルーミー','タンク','N-BOX','プリウス','アクア','キックス','ノート','セレナ']},
  {key:'grade', label:'グレード', type:'text'},
  {key:'model', label:'型式', type:'text'},
  {key:'year', label:'年式', type:'choice', options:['R7','R6','R5','R4','R3','R2','R1','H31','H30','H29','H28','H27','H26','H25'], month:true},
  {key:'mileage', label:'走行(km)', type:'num'},
  {key:'cc', label:'排気量(cc)', type:'num'},
  {key:'color', label:'色', type:'choice', options:['パール','ホワイト','ブラック','シルバー','グレー','レッド','ブルー','ベージュ','ブラウン','グリーン','イエロー','2トーン']},
  {key:'shift', label:'シフト', type:'choice', options:['AT','CVT','FAT','CAT','MT','5F','6F']},
  {key:'inspection', label:'車検', type:'text', options:['なし','R7年','R8年','R9年']},
  {key:'repair', label:'修復歴', type:'choice', options:['なし','あり']},
  {key:'exterior', label:'外装評価', type:'choice', options:['A','B','C','D','E']},
  {key:'interior', label:'内装評価', type:'choice', options:['A','B','C','D','E']},
  {key:'sales', label:'セールス', type:'text', wide:true, options:['ナビ','バックカメラ','ETC','両側パワスラ','LEDヘッド','禁煙車','ワンオーナー','記録簿']},
];

// 検査員報告の定型文
const REPORT = {
  '注意事項': ['メーター交換車','メーター改ざん車','走行不明車','冠水歴の為 1点','腐食穴の為 2点','消火剤散布歴車の為 1点','修復歴','並行車？','ナンバー後日','現状','BTあり'],
  'チェックランプ': ['エンジンチェックランプ点灯','エアバッグ警告灯点灯','ABS警告灯点灯','ブレーキ警告灯点灯','警告灯点灯'],
  '電装品': ['ナビ不良','エアコン不良','パワーウインドウ不良','スライドドア不良','オーディオ不良','バッテリー弱'],
  '機関・機構': ['異音','オイル漏れ','オイル滲み','水漏れ','白煙','ミッション滑り','足回り異音'],
  '内装': ['ルーム内一部汚れ','シート擦れ','シートヘタリ','シートシミ','天井汚れ','タバコ臭','ペット臭','焦げ穴'],
  '外装': ['左','右','F','R','小','（大）','（多）','各','キズ','凹','補修','ペイント','波','ムラ','欠','穴','一部','あり'],
  '社外品': ['社外アルミ','社外マフラー','社外ナビ','社外エアロ','車高調','ローダウン'],
  '改造・加工': ['構造変更','改造あり','加工あり','公認'],
  'その他': ['記録簿あり','保証書あり','取説あり','スペアキーあり','禁煙車'],
};

// 検査表示記号（暫定。正式な定義は検査基準PDFで要照合）。3列で同系統が1行に並ぶ順
//   A:キズ U:凹み B:キズを伴う凹み W:補修跡 P:塗装 XX:交換済 X:要交換
//   S:サビ G:石跳ね C:腐食 E:えくぼ Y:ひび・割れ
const SYMBOLS = ['A1','A2','A3','U1','U2','U3','B1','B2','B3','W1','W2','W3',
  'P','XX','X','S1','S2','G','C1','C2','E1','Y1','Y2'];

// ---- 状態 -----------------------------------------------------------------

const LIST = window.MANIFEST || [];
const TAB_TITLE = {basic:'基本事項', report:'検査員報告', symbol:'検査表示記号'};
const store = {
  get(k){ try { return JSON.parse(localStorage.getItem(k)); } catch { return null; } },
  set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
  del(k){ try { localStorage.removeItem(k); } catch {} },
};
let cur = null, data = null;
let tab = 'basic', imgKind = 'damage', fieldKey = 'lotNo', reportCat = '注意事項', selPart = null;
let undo = [], caret = null;

const emptyData = () => ({basic:{}, report:'', marks:[]});
const save = () => store.set('shuppin:' + cur.id, data);

function toast(msg){
  const t = $('#toast'); t.textContent = msg; t.hidden = false;
  clearTimeout(toast.timer); toast.timer = setTimeout(() => t.hidden = true, 2200);
}

function ask(label, value, done){
  $('#modalLabel').textContent = label;
  $('#modalInput').value = value || '';
  $('#modal').hidden = false; $('#modalInput').focus();
  $('#modalForm').onsubmit = e => { e.preventDefault(); $('#modal').hidden = true; done($('#modalInput').value.trim()); };
}
$('#modalCancel').onclick = () => $('#modal').hidden = true;

// ---- 車両・画像 -----------------------------------------------------------

function loadVehicle(id){
  cur = LIST.find(v => v.id === id) || LIST[0];
  data = Object.assign(emptyData(), store.get('shuppin:' + cur.id));
  undo = []; caret = null;
  store.set('shuppin:last', cur.id);
  // 画像枠は傷凹み画像を横幅いっぱいにして切れない比率に合わせる（再塗装もこの枠内に表示）
  // 画像サイズはパネル選択時の自動ズーム位置の計算にも使う
  ['damage', 'repaint'].forEach(kind => {
    imgSize[kind] = null;
    if (!cur[kind]) return;
    const probe = new Image(), forId = cur.id;
    probe.onload = () => {
      if (cur.id !== forId) return;
      imgSize[kind] = {w: probe.naturalWidth, h: probe.naturalHeight};
      if (kind === 'damage') viewer.style.aspectRatio = `${probe.naturalWidth}/${probe.naturalHeight}`;
    };
    probe.src = cur[kind];
  });
  resetViews(); showPhoto(); render();
}

function showPhoto(){
  document.querySelectorAll('.seg button').forEach(b => b.classList.toggle('on', b.dataset.img === imgKind));
  const src = cur && cur[imgKind];
  $('#photo').hidden = !src; $('#noPhoto').hidden = !!src;
  if (src) $('#photo').src = src; else $('#photo').removeAttribute('src');
  applyView();
}

// ---- 画像のズーム・パン（傷凹み／再塗装で個別に保持） -----------------------

const MAX_ZOOM = 8;
const views = {}, imgSize = {};
const viewer = $('#viewer'), photo = $('#photo');
function resetViews(){ views.damage = {s:1, x:0, y:0}; views.repaint = {s:1, x:0, y:0}; }

// 展開図のパネル選択に連動して画像の該当箇所を表示する（画像ごとにルールが異なる）
// 傷凹み:
//   フェンダ: 前→画像の左上/右上、後→左下/右下を2倍
//   ドア・サイドステップ: 1.8倍で高さ中央、左側→最左／右側→最右
//   中央の部品（その他）: 中央を1.2倍
// 再塗装:
//   左半分の部品→1.8倍で高さ中央・最左、右半分→最右、中央の部品→等倍（ズーム・パンなし）
const DAMAGE_FOCUS = {
  left_front_fender: 'tl', left_rear_fender: 'bl', right_front_fender: 'tr', right_rear_fender: 'br',
  left_front_door: 'ml', left_rear_door: 'ml', left_side_step: 'ml',
  right_front_door: 'mr', right_rear_door: 'mr', right_side_step: 'mr',
};
const focusTarget = {
  damage: part => DAMAGE_FOCUS[part] || 'center',
  repaint: part => part.startsWith('left_') ? 'ml' : part.startsWith('right_') ? 'mr' : 'none',
};
function focusPanel(part){
  const W = viewer.clientWidth, H = viewer.clientHeight;
  ['damage', 'repaint'].forEach(kind => {
    const target = focusTarget[kind](part);
    if (target === 'none') { views[kind] = {s:1, x:0, y:0}; return; }
    // object-fit:contain で枠内に実際に描かれている画像の範囲
    const n = imgSize[kind] || {w: W, h: H}, k = Math.min(W / n.w, H / n.h);
    const cw = n.w * k, ch = n.h * k, ox = (W - cw) / 2, oy = (H - ch) / 2;
    let s, cx, cy;
    if (target === 'center') { s = 1.2; cx = ox + cw / 2; cy = oy + ch / 2; }
    else if (target[0] === 'm') { // 画像の左端（右端）を枠の左端（右端）に合わせる
      s = 1.8; cy = oy + ch / 2;
      cx = target[1] === 'l' ? ox + W / (2 * s) : ox + cw - W / (2 * s);
    }
    else {
      s = Math.min(W / (cw / 2), H / (ch / 2));
      cx = ox + cw * (target[1] === 'l' ? 0.25 : 0.75);
      cy = oy + ch * (target[0] === 't' ? 0.25 : 0.75);
    }
    views[kind] = {s, x: W / 2 - s * cx, y: H / 2 - s * cy};
  });
  applyView();
}

// 画像が枠の外に抜けないよう移動量を制限して反映
function applyView(){
  const v = views[imgKind], w = viewer.clientWidth, h = viewer.clientHeight;
  v.s = Math.min(MAX_ZOOM, Math.max(1, v.s));
  v.x = Math.min(0, Math.max(w - w * v.s, v.x));
  v.y = Math.min(0, Math.max(h - h * v.s, v.y));
  photo.style.transform = `translate(${v.x}px,${v.y}px) scale(${v.s})`;
  $('#zoomLevel').hidden = v.s <= 1.01;
  $('#zoomLevel').textContent = `×${v.s.toFixed(1)}　リセット`;
}

// 枠内の点 (px,py) を中心に倍率を s に変更
function zoomAt(s, px, py){
  const v = views[imgKind], k = Math.min(MAX_ZOOM, Math.max(1, s)) / v.s;
  v.x = px - (px - v.x) * k; v.y = py - (py - v.y) * k; v.s *= k;
  applyView();
}

const pointers = new Map();
let gesture = null, lastTap = 0;
const localPt = e => { const r = viewer.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top]; };
function startGesture(){
  const v = views[imgKind], pts = [...pointers.values()];
  gesture = pts.length >= 2
    ? {dist: Math.hypot(pts[0][0] - pts[1][0], pts[0][1] - pts[1][1]), s: v.s, mid: [(pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2]}
    : {pt: pts[0], moved: false};
}
viewer.addEventListener('pointerdown', e => {
  if (e.target.closest('button')) return;
  viewer.setPointerCapture(e.pointerId);
  pointers.set(e.pointerId, localPt(e)); startGesture();
});
viewer.addEventListener('pointermove', e => {
  if (!pointers.has(e.pointerId)) return;
  const prev = pointers.get(e.pointerId), now = localPt(e), v = views[imgKind];
  pointers.set(e.pointerId, now);
  if (pointers.size >= 2) {
    const pts = [...pointers.values()];
    const mid = [(pts[0][0] + pts[1][0]) / 2, (pts[0][1] + pts[1][1]) / 2];
    v.x += mid[0] - gesture.mid[0]; v.y += mid[1] - gesture.mid[1]; gesture.mid = mid;
    zoomAt(gesture.s * Math.hypot(pts[0][0] - pts[1][0], pts[0][1] - pts[1][1]) / gesture.dist, mid[0], mid[1]);
  } else {
    v.x += now[0] - prev[0]; v.y += now[1] - prev[1];
    if (Math.hypot(now[0] - gesture.pt[0], now[1] - gesture.pt[1]) > 8) gesture.moved = true;
    applyView();
  }
});
const endPointer = e => {
  if (!pointers.has(e.pointerId)) return;
  const tap = pointers.size === 1 && gesture && !gesture.moved && e.type === 'pointerup';
  const pt = pointers.get(e.pointerId);
  pointers.delete(e.pointerId);
  if (pointers.size) return startGesture();
  // ダブルタップ: 等倍なら2.5倍、拡大中なら等倍に戻す
  if (tap) {
    if (Date.now() - lastTap < 300) { views[imgKind].s > 1.01 ? zoomAt(1, ...pt) : zoomAt(2.5, ...pt); lastTap = 0; }
    else lastTap = Date.now();
  }
};
viewer.addEventListener('pointerup', endPointer);
viewer.addEventListener('pointercancel', endPointer);
viewer.addEventListener('wheel', e => { // PC確認用：ホイールでズーム
  e.preventDefault();
  zoomAt(views[imgKind].s * (e.deltaY < 0 ? 1.2 : 1 / 1.2), ...localPt(e));
}, {passive: false});
$('#zoomLevel').onclick = () => { views[imgKind] = {s:1, x:0, y:0}; applyView(); };
window.addEventListener('resize', () => cur && applyView());
resetViews();

$('#vehicle').innerHTML = LIST.map(v =>
  `<option value="${esc(v.id)}">${esc(v.id)}${v.damage ? ' 傷' : ''}${v.repaint ? ' 塗' : ''}</option>`).join('');
$('#vehicle').onchange = e => loadVehicle(e.target.value);
document.querySelectorAll('.seg button').forEach(b => b.onclick = () => { imgKind = b.dataset.img; showPhoto(); });
$('#photo').onerror = () => { $('#photo').hidden = true; $('#noPhoto').hidden = false; };
$('#viewerSize').onclick = () => {
  const small = $('#app').classList.toggle('small-viewer');
  $('#viewerSize').textContent = small ? '▴' : '▾';
  resetViews(); applyView();
};

// ---- 描画 -----------------------------------------------------------------

function render(){
  $('#tabTitle').textContent = TAB_TITLE[tab];
  $('#app').classList.toggle('tab-symbol', tab === 'symbol');
  document.querySelectorAll('.drawer .nav').forEach(b => b.classList.toggle('on', b.dataset.tab === tab));
  ({basic:renderBasic, report:renderReport, symbol:renderSymbol})[tab]();
}

const key = (label, attrs = '', cls = '') => `<button class="key ${cls}" ${attrs}>${label}</button>`;

// 基本事項
function renderBasic(){
  $('#sheet').innerHTML = `<div class="fields">${FIELDS.map(f =>
    `<button class="field ${f.wide ? 'wide' : ''} ${f.cls || ''} ${f.key === fieldKey ? 'on' : ''}" data-field="${f.key}">
      <i>${f.label}</i><span>${esc(data.basic[f.key])}</span></button>`).join('')}</div>`;
  $('#sheet').querySelectorAll('.field').forEach(b => b.onclick = () => { fieldKey = b.dataset.field; renderBasic(); });

  const f = FIELDS.find(x => x.key === fieldKey);
  const val = data.basic[f.key] || '';
  let html = `<h4><span>${f.label} の入力</span><span>${esc(val)}</span></h4>`;
  if (f.type === 'num') {
    html += `<div class="keys c3">${['7','8','9','4','5','6','1','2','3','0','00'].map(n => key(n, `data-num="${n}"`)).join('')}${key('1字消す', 'data-act="bs"', 'red')}</div>`;
  } else {
    const isOn = o => f.wide ? val.split(' ／ ').includes(o) : (o === val || val.startsWith(o + ' /'));
    html += `<div class="keys">${(f.options || []).map(o => key(esc(o), `data-val="${esc(o)}"`, isOn(o) ? 'on' : '')).join('')}</div>`;
  }
  html += `<div class="keys c3" style="margin-top:5px">${key('手入力', 'data-act="text"')}${key('クリア', 'data-act="clear"', 'red')}${key('次の項目 ›', 'data-act="next"', 'blue')}</div>`;
  $('#pad').innerHTML = html;

  $('#pad').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    const set = v => { data.basic[f.key] = v; save(); renderBasic(); };
    if (b.dataset.num) set(val + b.dataset.num);
    else if (b.dataset.val) {
      const v = b.dataset.val;
      if (f.wide) { // セールスポイントは複数選択
        const items = val ? val.split(' ／ ') : [];
        set((items.includes(v) ? items.filter(x => x !== v) : [...items, v]).join(' ／ '));
      } else if (f.key === 'score') { if (checkScore(v)) set(v); }
      else if (f.month) ask(`${f.label}：${v} の月（省略可）`, '', m => set(m ? `${v} / ${m}` : v));
      else set(v);
    }
    else if (b.dataset.act === 'bs') set(val.slice(0, -1));
    else if (b.dataset.act === 'clear') set('');
    else if (b.dataset.act === 'text') ask(f.label, val, v => set(v));
    else if (b.dataset.act === 'next') { fieldKey = FIELDS[(FIELDS.indexOf(f) + 1) % FIELDS.length].key; renderBasic(); }
  };
}

// 修復歴に関わる入力があれば評価点確定前に確認する
function checkScore(v){
  const msgs = [];
  if (data.basic.repair === 'あり' && !/^R/.test(v)) msgs.push('修復歴「あり」ですが評価点が R / RA ではありません。');
  const rel = data.marks.filter(m => ['XX','X','W2','W3'].includes(m.sym));
  if (rel.length) msgs.push('修復歴に関わる可能性のある記号: ' + rel.map(m => `${partLabel(m.part)} ${m.sym}`).join('、'));
  return !msgs.length || confirm(msgs.join('\n') + '\n\nこの評価点で確定しますか？');
}

// 検査員報告
function renderReport(){
  $('#sheet').innerHTML = `<textarea id="report" class="report" placeholder="下のボタンで定型文を入力できます（直接入力も可）">${esc(data.report)}</textarea>`;
  const ta = $('#report');
  ta.oninput = () => { data.report = ta.value; save(); };
  ta.addEventListener('beforeinput', () => undo.push(ta.value));
  ['keyup','click','select'].forEach(ev => ta.addEventListener(ev, () => caret = [ta.selectionStart, ta.selectionEnd]));

  $('#pad').innerHTML =
    `<div class="tabs">${Object.keys(REPORT).map(c => key(c, `data-cat="${c}"`, (c === reportCat ? 'on ' : '') + (c === '注意事項' ? 'red' : ''))).join('')}</div>
    <h4>${reportCat}</h4>
    <div class="keys">${REPORT[reportCat].map(p => key(esc(p), `data-ins="${esc(p)}"`)).join('')}</div>
    <h4>編集</h4>
    <div class="keys c5">${key('中点', 'data-ins="・"')}${key('読点', 'data-ins="、"')}${key('スペース', 'data-ins="　"')}${key('改行', 'data-ins="&#10;"', 'green')}${key('1字消す', 'data-act="bs"', 'red')}</div>
    <div class="keys c3" style="margin-top:5px">${key('1つ戻す', 'data-act="undo"')}${key('全消去', 'data-act="clear"', 'red')}${key('確定', 'data-act="done"', 'blue')}</div>`;

  $('#pad').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.cat) { reportCat = b.dataset.cat; renderReport(); return; }
    const v = ta.value;
    const [s, en] = caret || [v.length, v.length];
    const apply = (nv, pos) => { undo.push(v); data.report = ta.value = nv; caret = [pos, pos]; save(); };
    if (b.dataset.ins != null) {
      const t = b.dataset.ins;
      apply(v.slice(0, s) + t + v.slice(en), s + t.length);
    }
    else if (b.dataset.act === 'bs' && (s > 0 || en > s)) {
      const from = en > s ? s : s - 1;
      apply(v.slice(0, from) + v.slice(en), from);
    }
    else if (b.dataset.act === 'undo') {
      if (!undo.length) return toast('戻せる操作がありません');
      data.report = ta.value = undo.pop(); caret = null; save();
    }
    else if (b.dataset.act === 'clear' && v && confirm('検査員報告をすべて消去しますか？')) apply('', 0);
    else if (b.dataset.act === 'done') toast('検査員報告を保存しました');
  };
}

// パネル内に記号を文字で並べる（パネル幅に応じて折り返し、外接矩形の中央に配置）
const SYMBOL_FONT = 64;
function panelText(p, syms){
  const xs = p.poly.map(q => q[0]), ys = p.poly.map(q => q[1]);
  const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
  const perLine = Math.max(1, Math.floor((x1 - x0) / (SYMBOL_FONT * 1.5)));
  const lines = [];
  for (let i = 0; i < syms.length; i += perLine) lines.push(syms.slice(i, i + perLine).join(' '));
  const cx = (x0 + x1) / 2, top = (y0 + y1) / 2 - (lines.length - 1) * SYMBOL_FONT / 2;
  return `<text x="${cx}">${lines.map((l, i) => `<tspan x="${cx}" y="${top + i * SYMBOL_FONT}">${esc(l)}</tspan>`).join('')}</text>`;
}

// 検査表示記号：左3/5に記号ボタン、右2/5に展開図。パネルを選んでから記号を押す
function renderSymbol(){
  const symsOf = id => data.marks.filter(m => m.part === id).map(m => m.sym);
  const ai = (cur.parts || []).filter(p => p.scratch || p.dent)
    .map(p => `${p.camera} ${p.part}：${p.scratch ? 'キズ' + p.scratch : ''}${p.dent ? ' 凹' + p.dent : ''}`);

  $('#sheet').innerHTML = `
    <svg class="diagram" id="diagram" viewBox="0 0 ${DIAGRAM.width} ${DIAGRAM.height}">
      <image href="${DIAGRAM.image}" width="${DIAGRAM.width}" height="${DIAGRAM.height}"/>
      ${PARTS.map(p => `<polygon data-part="${p.id}" class="${p.id === selPart ? 'sel' : ''}" points="${p.poly.join(' ')}"/>`).join('')}
      ${PARTS.map(p => { const s = symsOf(p.id); return s.length ? panelText(p, s) : ''; }).join('')}
    </svg>
    <p class="sel-label">${selPart ? esc(partLabel(selPart)) : 'パネルをタップして選択'}</p>
    ${ai.length ? `<div class="hint"><b>AI検出（参考）</b><br>${ai.map(esc).join('<br>')}</div>` : ''}`;

  $('#diagram').onclick = e => {
    const part = e.target.dataset.part;
    if (!part) return;
    selPart = part === selPart ? null : part;
    if (selPart) focusPanel(selPart);
    renderSymbol();
  };

  $('#pad').innerHTML =
    `<div class="keys c3">${SYMBOLS.map(s => key(s, `data-sym="${s}"`, selPart && symsOf(selPart).includes(s) ? 'applied' : '')).join('')}</div>
    <div class="keys c3" style="margin-top:5px">${key('1つ消す', 'data-act="pop"', 'red')}${key('全消去', 'data-act="clear"', 'red')}${key('次へ ›', 'data-act="next"', 'blue')}</div>`;
  $('#pad').onclick = e => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.act === 'next') { tab = 'basic'; fieldKey = 'score'; render(); toast('最後に評価点を入力してください'); return; }
    if (!selPart) return toast('先に展開図のパネルを選択してください');
    if (b.dataset.sym) { // 選択中パネルに入力済みの記号なら削除、未入力なら追加
      const sym = b.dataset.sym, has = m => m.part === selPart && m.sym === sym;
      if (data.marks.some(has)) data.marks = data.marks.filter(m => !has(m));
      else data.marks.push({sym, part: selPart});
    }
    else if (b.dataset.act === 'pop') {
      const i = data.marks.map(m => m.part).lastIndexOf(selPart);
      if (i >= 0) data.marks.splice(i, 1);
    }
    else if (b.dataset.act === 'clear') {
      if (!symsOf(selPart).length || !confirm(`${partLabel(selPart)} の記号をすべて消去しますか？`)) return;
      data.marks = data.marks.filter(m => m.part !== selPart);
    }
    save(); renderSymbol();
  };
}

// ---- 左右タブ（ドロワー） -------------------------------------------------

const drawer = $('#drawer'), scrim = $('#scrim'), edgeTab = $('#edgeTab');
const openDrawer = open => {
  drawer.classList.toggle('open', open); scrim.classList.toggle('open', open);
  drawer.setAttribute('aria-hidden', String(!open));
};
function setSide(side){
  ['left','right'].forEach(s => { drawer.classList.toggle(s, s === side); edgeTab.classList.toggle(s, s === side); });
  $('#sideBtn').textContent = side === 'right' ? 'タブを左側に表示' : 'タブを右側に表示';
  store.set('shuppin:side', side);
}
edgeTab.onclick = $('#menuBtn').onclick = () => openDrawer(true);
scrim.onclick = () => openDrawer(false);
document.querySelectorAll('.drawer .nav').forEach(b => b.onclick = () => { tab = b.dataset.tab; render(); openDrawer(false); });
$('#sideBtn').onclick = () => setSide(drawer.classList.contains('right') ? 'left' : 'right');
$('#exportBtn').onclick = () => {
  const blob = new Blob([JSON.stringify({id: cur.id, ...data}, null, 2)], {type: 'application/json'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob); a.download = `shuppinhyo_${cur.id}.json`; a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
};
$('#resetBtn').onclick = () => {
  if (!confirm(`${cur.id} の入力内容をすべて消去しますか？`)) return;
  store.del('shuppin:' + cur.id); loadVehicle(cur.id); openDrawer(false);
};

// 画面端からのスワイプでもタブを開く
let swipe = null;
document.addEventListener('touchstart', e => {
  const x = e.touches[0].clientX, w = window.innerWidth, side = drawer.classList.contains('right') ? 'right' : 'left';
  swipe = (side === 'right' ? x > w - 20 : x < 20) ? {x, side} : null;
}, {passive: true});
document.addEventListener('touchmove', e => {
  if (!swipe) return;
  const dx = e.touches[0].clientX - swipe.x;
  if ((swipe.side === 'right' && dx < -40) || (swipe.side === 'left' && dx > 40)) { openDrawer(true); swipe = null; }
}, {passive: true});

// 下部のボタンエリアを左右にスワイプして3画面（基本事項・検査員報告・検査表示記号）を切り替える
//   左へスワイプ→次の画面、右へスワイプ→前の画面（端では止まる）
const TABS = Object.keys(TAB_TITLE);
let padSwipe = null;
$('#pad').addEventListener('touchstart', e => {
  const t = e.touches[0], w = window.innerWidth, right = drawer.classList.contains('right');
  // 複数指・横スクロールする分類タブ上・ドロワーを開く画面端からの操作は対象外
  padSwipe = e.touches.length > 1 || e.target.closest('.tabs') || (right ? t.clientX > w - 20 : t.clientX < 20)
    ? null : {x: t.clientX, y: t.clientY};
}, {passive: true});
$('#pad').addEventListener('touchend', e => {
  if (!padSwipe) return;
  const t = e.changedTouches[0], dx = t.clientX - padSwipe.x, dy = t.clientY - padSwipe.y;
  padSwipe = null;
  if (Math.abs(dx) < 60 || Math.abs(dx) < Math.abs(dy) * 1.5) return; // 縦スクロールやタップは無視
  const i = TABS.indexOf(tab) + (dx < 0 ? 1 : -1);
  if (i < 0 || i >= TABS.length) return;
  tab = TABS[i]; render();
  const pad = $('#pad'), cls = dx < 0 ? 'slide-next' : 'slide-prev';
  pad.classList.remove('slide-next', 'slide-prev'); void pad.offsetWidth; pad.classList.add(cls);
}, {passive: true});
$('#pad').addEventListener('touchcancel', () => padSwipe = null);

// ---- 起動 -----------------------------------------------------------------

setSide(store.get('shuppin:side') || 'right');
if (TAB_TITLE[location.hash.slice(1)]) tab = location.hash.slice(1); // 例: index.html#symbol
if (LIST.length) {
  const last = store.get('shuppin:last');
  const first = (LIST.find(v => v.id === last) || LIST.find(v => v.damage) || LIST[0]).id;
  $('#vehicle').value = first; loadVehicle(first);
} else {
  $('#sheet').innerHTML = '<p class="empty">画像一覧がありません。tools\\build-manifest.ps1 を実行してください。</p>';
}
